export async function POST(request) {
  const { messages } = await request.json();

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: `Sen deneyimli, profesyonel bir iş asistanısın. 
Görevlerin: e-posta taslakları yazmak, rapor ve toplantı özetleri oluşturmak, 
sunum içerikleri hazırlamak, proje planları ve iş stratejileri geliştirmek.
Yanıtların her zaman net, yapılandırılmış ve uygulanabilir olsun.
Türkçe konuşursun. Gerektiğinde madde madde veya başlıklarla yanıt ver.`,
      messages,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    return Response.json({ error: data.error?.message || "API hatası" }, { status: 500 });
  }

  const text = data.content?.map((b) => b.text || "").join("") || "";
  return Response.json({ reply: text });
}
